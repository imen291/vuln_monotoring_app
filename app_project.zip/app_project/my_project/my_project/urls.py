from django.contrib import admin
from django.urls import path,include
from show_cve_table import views
from admin_dash import views as admin_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('home',admin_views.home,name='home'),
    path('login_admin',admin_views.login_admin,name='login_admin'),
    path('dashboard',admin_views.dashboard,name='dash_admin'),
    path('cve/', views.index),
    #path('login_client',views.login_page,name='login_client'),
]
