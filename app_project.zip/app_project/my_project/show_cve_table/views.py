from django.http import HttpResponse
from django.shortcuts import render,redirect
import mysql.connector 
from django.http import HttpResponse
from .models import cve_data

def index(request):
    cve_data = cve_data.objects.all()
    context={
        'cve_data': cve_data
    }
    return render(request,'show_cve_table/index.html', context)
'''

def login_page(request):
        #return render (request,'show_cve_table/login_client.html')

        con = mysql.connector.connect(host='localhost',user='usr',password='password123')
        cursor=con.cursor()
        con2=mysql.connector.connect(host='localhost',user='usr',password='password123')
        cursor2=con2.cursor()
        sqlcommand="select username from show_cve_table_client"
        sqlcommand1="select password from show_cve_table_client"
        u=[]
        p=[]
        cursor.execute(sqlcommand)
        cursor2.execute(sqlcommand1)
        for i in cursor:
            u.append(i)
        for j in cursor2:
            p.append(j)
        print(u)
        print(p)
        if request.method=='Post':
            username=request.POST['username']    
            password=request.POST['password']   
        return render (request,'show_cve_table/login_client.html')
 '''   

'''
def client_login (request): 
    if request.method  == 'POST' :
        client=Client()
        client.username=request.POST['username']
        client.password=request.POST['password']

        try:
            client=Client.clientAuth_objects.get(username=username,password=password)
            if client is not None :
                return render(request,'show_cve_table/dashboard.html')
            else :
                return redirect ('show_cve_table/login_client.html')
        except Exception as identifier:
            return redirect('/')
'''


    




    

