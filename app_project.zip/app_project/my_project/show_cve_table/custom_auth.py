from http import client
from show_cve_table.models import Client

class client_auth():
    def authenticate(self,request,username,password):
        try:
            client=Client.objects.get(username)
            success= client.check_password(password)
            if success:
                return client
        except Client.DoesNotExist:
            pass
        return None

    def get_client (self,username):
        try:
            return Client.objects.get(pk=username)
        except:
            return None