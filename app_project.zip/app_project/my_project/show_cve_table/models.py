from http import client
from tabnanny import verbose
from django.db import models


class cve_data(models.Model):
    
    Cve_id =models.CharField(primary_key=True, max_length=200)
    Assigner = models.CharField(max_length=200, blank=True, null=True)
    Description = models.CharField(max_length=4500, blank=True, null=True)
    Publish_date=models.CharField(max_length=200, blank=True, null=True)
    Last_modified_date=models.CharField(max_length=200, blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'test'
'''
    data_format = models.CharField(max_length=10, blank=True, null=True)
    data_version = models.IntegerField(blank=True, null=True)
    id = models.CharField(primary_key=True, max_length=30)
'''
    
