from lib2to3.pgen2.pgen import ParserGenerator
from django.urls import path
from . import views

urlpatterns=[
    path('',views.index,name='index page'),
    path('login_client',views.login_page,name='login_client')
] 