from django.shortcuts import render
from django.http import HttpResponse

def home(request):
    return HttpResponse ('<h1> home page </h1>')

def login_admin(request):
    return  render(request,'admin_dash/sign_in.html')

def dashboard(request):
    return HttpResponse('dashboard admin')

# Create your views here.
