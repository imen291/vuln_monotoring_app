from django.shortcuts import render

def cve(request):
    return render(request,'admin_dash/index.html')
