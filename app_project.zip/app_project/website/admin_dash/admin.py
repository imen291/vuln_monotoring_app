from django.contrib import admin


# Register your models here.


admin.site.site_header = 'Admin Dashboard'
admin.site.site_title= 'Admin_Dash'
