from secrets import choice
from django.db import models


class Client(models.Model):
    id= models.AutoField
    client_name=models.CharField(max_length=30)
    email=models.CharField(max_length=50)
    password=models.CharField(max_length=30)
    Added = models.DateTimeField(null=True)
    
    def __str__(self):
        return self.client_name

class Category(models.Model):
    choice=(
        ('materiel','materiel'),
        ('logiciel','logiciel'),
        ('reseau','reseau'),
    )
    name= models.CharField(max_length=50,choices=choice)

class Product (models.Model):
    choice=(
        ('firewall','firewall'),
        ('router','router'),
        ('switch','switch'),
        ('hub','hub'),
        ('repeater','repeater'),
        ('bridge','bridge'),
        ('ordinateur de bureau','ordinateur de bureau'),
        ('imprimante','imprimante'),
        ('scanner','scanner'),
        ('server','server'),
        ('data center','data center'),
        ('serveur de messagerie','serveur de messagerie'),
        ('logiciel serveur web','logiciel server web'),
        ('SGBD','SGBD'),
        ('OS','OS'),
        ('systeme de gestion de contenu','systeme de gestion de contenu'),
    )
    choix=(
        ('materiel','materiel'),
        ('logiciel','logiciel'),
        ('reseau','reseau'),
    )
    category= models.ForeignKey(Category,on_delete=models.PROTECT,choices=choix)
    type= models.CharField(max_length=50,choices=choice)
    name= models.CharField(max_length=50)
    version= models.CharField(max_length=50)
    
