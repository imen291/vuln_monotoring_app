from unicodedata import name
from django.shortcuts import render,redirect
import mysql.connector
from django.contrib import messages
from operator import itemgetter

from .forms import ProductForm
from .models import *


def welcome2(req):
    return render(req,'loginapp/welcome2.html') 

def welcome(req):
    return render(req,'loginapp/welcome.html')

def dashboard(req):
    form:ProductForm
    context={
        'category': Category.objects.all(),
        'product': Product.objects.all(),
        'form': form
    }
    return render(req,'loginapp/dashboard1.html',context)

def login(req):
    con = mysql.connector.connect(host='localhost',user='usr',password='password123',database='pfe_db')
    cursor=con.cursor()
    con2=mysql.connector.connect(host='localhost',user='usr',password='password123',database='pfe_db')
    cursor2=con2.cursor()
    con3=mysql.connector.connect(host='localhost',user='usr',password='password123',database='pfe_db')
    cursor3=con3.cursor()
    sqlcommand="select email from loginapp_client"
    sqlcommand1="select password from loginapp_client"
    sqlcommand2="select client_name from loginapp_client"
    cursor.execute(sqlcommand)
    cursor2.execute(sqlcommand1)
    cursor3.execute(sqlcommand2)
    n=[]
    e=[]
    p=[]
    for i in cursor:
        e.append(i)
    for j in cursor2:
        p.append(j)
    for k in cursor3:
        n.append(k)
   
    res = list(map(itemgetter(0),e))
    res2= list(map(itemgetter(0),p))
    res3= list(map(itemgetter(0),n))

    print(e)
    if req.method=='POST':
        email=req.POST['email']    
        password=req.POST['password'] 
        i=0
        k=len(res)
        while i<k:
            if res[i]==email and res2[i]==password:
                
                #return redirect ('clientdash')
                return render(req,'loginapp/dashboard1.html',{'email':email,'name':res3[i]})
                
            i+=1
        else:
                messages.info(req,"check email or password")
                return redirect ('clientlogin')
                #return redirect(login)
             

    return render(req,'loginapp/login.html')




def infra(req):
    
    return render(req,'loginapp/infra.html')

def comp(req):
    #form = ProductForm()
    #context = {'form':form}
    #return render(req,'loginapp/comp.html',context)
  if req.method == 'POST':
    if req.POST.get('category') and req.POST.get('type') and req.POST.get('name') and req.POST.get('version'):
      post=Product()
      post.category= req.POST.get('category')
      post.type= req.POST.get('type')
      post.name= req.POST.get('name')
      post.version= req.POST.get('version')
      post.save()          
      
      return render(req, 'loginapp/comp.html')  

  else:
    return render(req,'loginapp/comp.html')
    
    
    