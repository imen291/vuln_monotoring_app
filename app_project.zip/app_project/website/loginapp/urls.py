from django.urls import path   
from . import views
urlpatterns = [

    path('home/',views.welcome,name='welcome'),
    path('login/',views.login,name='clientlogin'),  #client_login
    path('dashboard/',views.dashboard,name='clientdash'),
  
]
    