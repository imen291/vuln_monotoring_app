
from django.contrib import admin
from django.urls import path,include
from loginapp import views 
from admin_dash import views as ad_views
urlpatterns = [
    path('admin/', admin.site.urls),
    path('ui/', include('loginapp.urls')),
    path('',views.welcome,name='welcome'),
    path('login',views.login,name='clientlogin'),  #client_login
    path('dashboard',views.dashboard,name='clientdash'),
    path('infra',views.infra,name='infra'),
    path('cve/',ad_views.cve,name='liste cve'),
    path('add_comp/',views.comp, name="comp")

]
